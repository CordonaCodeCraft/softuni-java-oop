package polymorphism.exercises.calculator.enums;

public enum InputType {
    INTEGER,
    OPERATOR,
    COMMAND,
}
