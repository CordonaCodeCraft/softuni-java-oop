package polymorphism.exercises.calculator.enums;

public enum Result {
    LOCKED,
    UNLOCKED,

}
