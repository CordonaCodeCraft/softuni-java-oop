package polymorphism.exercises.calculator.enums;

public enum Operator {
    NONE,
    MULTIPLY,
    DIVIDE,

}
