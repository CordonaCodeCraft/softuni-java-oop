package polymorphism.exercises.calculator.enums;

public enum Cache {
    LOCKED,
    UNLOCKED,

}
